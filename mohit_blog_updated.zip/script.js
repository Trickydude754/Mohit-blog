
// Dark Mode Toggle
const toggleBtn = document.getElementById("dark-toggle");
toggleBtn.addEventListener("click", () => {
  document.body.classList.toggle("dark");
  toggleBtn.textContent = document.body.classList.contains("dark") ? "🌞 Light Mode" : "🌙 Dark Mode";
});

// Language Toggle (Hindi/English)
const langToggle = document.getElementById("lang-toggle");
let isHindi = true;

langToggle.addEventListener("click", () => {
  const hindiElements = document.querySelectorAll(".lang-hi");
  const engElements = document.querySelectorAll(".lang-en");

  isHindi = !isHindi;
  langToggle.textContent = isHindi ? "🇬🇧 English" : "🇮🇳 हिंदी";

  hindiElements.forEach(el => el.style.display = isHindi ? "block" : "none");
  engElements.forEach(el => el.style.display = isHindi ? "none" : "block");
});
